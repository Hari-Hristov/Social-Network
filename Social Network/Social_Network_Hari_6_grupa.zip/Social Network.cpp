#include "Engine.h"

int main()
{
	Engine::getInstance().run();
}
